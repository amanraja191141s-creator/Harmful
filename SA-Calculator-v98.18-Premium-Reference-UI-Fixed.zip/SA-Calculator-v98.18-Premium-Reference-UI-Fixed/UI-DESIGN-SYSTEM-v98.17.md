# SA Calculator v98.17 — full reference rebuild

## Visual reference
The user-provided 16 November 2026 screenshot defines the design target: pure-black outer surround, deep midnight-navy app surface, metallic SA mark, cyan/electric-blue illuminated outlines, pale ice-blue form surfaces, vivid green result panels, blue gradient actions, and restrained gold accents.

## Layout interpretation
The supplied image is an 18-tool promotional contact sheet. It is not suitable as a literal 6-column interactive phone layout because its labels and controls would be too small to use. The app therefore uses the same visual grammar in each full-size screen: a compact SA Calculator brand header, a per-tool title strip, readable form/result cards, and touch-sized actions.

## Rebuilt visual layer
- Replaced the previous v98.16 appended CSS override with one v98.17 final visual layer.
- Compact brand header with logo, title, tagline and retained scientific/history/settings actions.
- Shared per-tool title strips for all 17 non-calculator tools.
- Midnight-blue calculator display and keypad; blue operators; gold equals key.
- Ice-blue cards and input controls; cyan illuminated outlines.
- Green semantic result panels; blue gradient primary actions.
- Currency pair panels, swap action, rate state, dock keypad, settings, drawer, history, scientific panel and currency picker styled consistently.
- Narrow phone, landscape, larger-screen, reduced-motion, forced-colour and high-contrast rules retained.

## Behaviour and native integration
This is a CSS-first visual rebuild. Existing DOM IDs, data attributes, calculations, currency provider logic, navigation, event listeners and persistence keys are preserved. Android native branding and window-inset patch remain part of the GitHub Actions build. Status/navigation bar rendering must still be checked on the target Vivo device and Android version.

## Release
- Version: `1.98.17-v98.17`
- Service-worker cache: `sa-calculator-v98-17-full-reference-rebuild`
- CSS source of truth: `assets/css/app.css` (single v98.17 final layer)
