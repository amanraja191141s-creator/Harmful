# SA Calculator v98.6 — Current file-by-file audit

Release: `1.98.6-v98.6`  
Audit date: 2026-11-15  
Input: `SA-Calculator-v98.5-APK-Ready-Clean-Fresh.zip`, corrected as v98.6.

## Runtime files

| File | Responsibility | v98.6 audit result |
|---|---|---|
| `index.html` | App shell, calculator and tool destinations, picker, settings and dialogs | Unique IDs, local script/style references and registered screens covered by release tests. |
| `assets/js/app.js` | Calculator engine, navigation, currency providers, settings, history and persistence | JavaScript syntax and calculator/currency/tool regression tests pass. |
| `assets/js/localization.js` | Offline-first interface localization | Localization inventories and runtime translation tests pass; native-speaker/device review remains manual. |
| `assets/js/currency-localized-names.js` | Localized currency display names | Bundled data is loaded by the app and service-worker precache. |
| `assets/js/theme-bootstrap.js` | First-paint theme/accent restoration | Loaded before the main stylesheet and included in service-worker precache. |
| `assets/css/app.css` | Themes, calculator layouts, dialogs and responsive rules | CSS structure, responsive design and regression checks pass; physical viewport rendering remains manual. |
| `service-worker.js` | Offline app shell and same-origin asset caching | Source and precache references validated. v98.6 fixes its omission from generated Android `www/` bundle. |
| `scripts/prepare-android-web.mjs` | Android web-root staging | Requires and copies the service worker beside `index.html`; build-output regression test verifies every precache asset. |
| `server.js` | Optional local static development server | Syntax, HTTP behavior, response headers and path/symlink security tests pass. Not a production API server. |
| `manifest.webmanifest` | PWA metadata and launcher icon | JSON valid; version aligned to `1.98.6-v98.6`. |
| `capacitor.config.json` | Capacitor Android wrapper configuration | `webDir` points to `www`; local HTTPS scheme and mixed-content restriction configured. |
| `package.json` | Project metadata and build/test commands | Version aligned to `1.98.6-v98.6`; Node test and Android build scripts present. |
| `assets/brand/sa-calculator-icon.png` | PWA/launcher icon | Required asset retained and verified during Android staging. |

## Regression tests

The `tests/` directory covers calculator parsing and scientific notation, memory state, tool calculations, currency freshness/math/pair persistence/provider fallback, localization inventories, HTML/navigation, screen design, service-worker precache references, Android staging, release metadata, and server safety.

Run with `npm test`. v98.6 result: **150 passed, 0 failed, 0 skipped**.

## Confirmed v98.6 correction

The v98.5 Android staging script copied `index.html`, `manifest.webmanifest` and `assets/` but did not copy `service-worker.js`, although `assets/js/app.js` registers `./service-worker.js`. The generated Capacitor web root therefore lacked the registered worker path. v98.6 adds the worker to required-source checks and the staging copy list, then tests the generated output and all worker precache targets.

## Android/release verification limits

- Android web staging was executed and its generated output inspected by automated regression tests.
- The ZIP contains Capacitor-ready source, not a generated signed APK.
- Physical Android System WebView testing, APK installation/upgrade, offline/online lifecycle, low-memory behavior, long-session performance, TalkBack, and real-device touch/IME behavior remain manual release gates.
- No claim of universal zero defects, signed release readiness, live provider uptime, or device certification is made.

## Currency/API provenance

No private Cloudflare Worker, private API adapter, provider credential or server-side currency proxy is shipped in this package. The app uses the public provider endpoints documented in `GLOBAL-CURRENCY-API.md`; cached and built-in estimate rates are labelled separately from live observations.

Historical continuity: the earlier `1.97.1-v97.1` audit and `1.98.2-v98.2` release verification are retained in the release history; their version labels describe those earlier releases, not the current v98.6 build.
