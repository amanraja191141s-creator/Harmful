## v1.98.6-v98.6 — Android service-worker bundle correction (2026-11-15)

- Fixed Android web staging: `service-worker.js` is now verified and copied beside `index.html` in `www/`, matching the app's registered worker URL.
- Added a build-output regression test that executes the staging script and verifies the worker plus every precache asset exist in the generated Android web bundle.
- Bumped app/package/manifest/cache identity to v98.6 so older cached assets cannot mask this packaging correction.
- Preserved calculator, scientific, memory, currency, tool, settings and localization behavior; no calculation algorithm was changed.
- Full regression suite: 150 passed, 0 failed. Android device/APK installation remains a separate manual/build-environment verification.

## v1.98.5-v98.5 — Clean source and Android APK build preparation (2026-11-14)

- Added a Capacitor Android configuration, validated offline web-asset staging, and a GitHub Actions debug-APK workflow. See `APK-ANDROID-BUILD-README.md`.
- Added Android build regression checks and ignored generated Android/SDK build outputs.
- Preserved runtime assets, currency/localization data, server, tests and audit records; no calculator or currency algorithms changed.
- APK generation is performed by GitHub Actions; this ZIP does not claim to contain a prebuilt APK.

## v1.98.4-v98.4 — Currency converter deep audit release (2026-11-14)

- Re-audited currency picker, saved pair, swap, both amount inputs, reverse conversion, decimal precision, provider fallback, cache freshness, offline labeling, retry behavior and refresh metadata.
- Kept the already-tested currency runtime logic unchanged; no reproducible currency defect justified changing rate math or provider selection.
- Added `CURRENCY-CONVERTER-DEEP-AUDIT-v98.4.md` with scope, findings and verification limits.
- Updated release/cache identity to prevent older service-worker assets from masking this release.
- Full suite on the base source: 146 passed, 0 failed.

## v1.98.4-v98.4 — Settings and tools UI cleanup (2026-11-14)

- Removed the duplicate visible Accent Highlight Color selector. The 15-option accessible Accent Palette picker is now the single visible accent-selection control; the legacy accent field remains hidden for saved-preference migration and existing theme synchronization.
- Removed the disabled Diagnostics switch because this standalone build has no diagnostics upload feature and the control could not be enabled. The privacy disclosure and local-data clearing action remain.
- Removed the non-functional “Independent product” status row, decorative drawer hint, and the lone promotional Unit Price intro. All 17 calculator/converter destinations and their calculation controls remain available.
- Preserved fullscreen, font size, wake lock, appearance mode, OLED, angle unit, live preview, implicit multiplication, number formatting, language, startup screen, restore inputs, favorites, history, clipboard, sound, haptics, privacy/data clearing, help, feedback and reset controls.
- Updated app/package/manifest version and service-worker cache namespace.
- Added regression checks confirming the duplicate/inert controls are absent, the hidden saved-accent compatibility field remains, all 12 settings groups remain, and unique control IDs are preserved.

## v1.98.1-v98.1 — rounded 12-digit scientific threshold (2026-11-14)

- Reworked the calculator integer-digit threshold to count integer digits directly instead of relying on a floating-point logarithm or a raw magnitude comparison. Twelve integer digits remain ordinary; a 13th integer digit switches to scientific notation.
- The 12-significant-digit display rounding is now considered before choosing ordinary vs scientific display, preventing values that round across 1e12 from being rendered as an ordinary 13-digit integer. The underlying calculation value remains unchanged.
- Unified radical preview formatting with the same 12/13-digit boundary so a rounded root cannot bypass the shared scientific display rule.
- Added boundary regression coverage for positive/negative values, values just below/at/above 1e12, rounded-up boundary cases, six-place scientific mantissas, preview formatting, and radical results.
- Advanced app metadata and service-worker cache namespace to v98.1.

## v1.98.0-v98.0 — six-place scientific mantissa and 13-digit threshold (2026-11-14)

- Scientific mantissas now render as `n.nnnnnn×10^x` (up to six fractional digits, trailing zeros removed) across scientific entry, live preview, committed result, and scientific continuation.
- All 12-digit integer values remain in ordinary notation; scientific notation starts at `1×10^12`, when a 13th integer digit is present. Tiny non-zero values continue to use scientific notation to avoid disappearing in fixed-decimal display.
- Display formatting is presentation-only; the raw calculator value remains the operand for follow-on operations. Regression coverage includes values around `1e11`/`1e12`, mantissa rounding, small magnitudes, and continuation preview.

## v1.97.9-v97.9 — recording-driven Error row stability (2026-11-14)

- Fixed a reproduced display shift: live Error preview previously expanded to 48–76px while the ordinary preview lane was 32px.
- Normal and live-error preview now share a fixed 32px flex lane and centered alignment; only semantic error color/weight differ.
- Committed Error keeps the secondary preview lane collapsed, consistent with the primary-row result-mode behavior.
- Added regression coverage for fixed row geometry, error typography metrics, and preserved 25px horizontal inset.
- Service-worker cache namespace updated to force the corrected stylesheet to load.

## v1.97.7-v97.7 — inclusive 12-digit scientific display and stable result continuation (2026-11-14)

- Calculator preview and committed result now switch to scientific notation at **12 integer digits** (inclusive, starting at `1e11`).
- The same formatter threshold is used for ordinary and radical calculation results; internal numeric precision remains unchanged.
- After `=`, pressing `+`, `−`, `×`, `÷`, or `^` preserves the visible scientific token (for example `1×10⁹`) in the continued expression while arithmetic uses the full raw numeric value.
- Added regression coverage for the 11/12-digit boundary and scientific-result continuation through all four arithmetic operators.

# SA Calculator v92

Independent calculator workspace release `1.94.0-v94`.

## Included tools

17 calculator screens are included:
1. Standard Calculator (scientific functions, DEG/RAD, memory)
2. Currency Converter
3. Unit Converter
4. Discount Calculator
5. Percent Calculator
6. Sales Tax Calculator
7. Body Metrics Calculator (BMI/BMR)
8. Date Calculator (local reminders/anniversaries)
9. Fuel Cost Calculator
10. Fuel Efficiency Calculator
11. Grade Average Calculator
12. Number Base Converter (HEX/DEC/OCT/BIN)
13. Loan / EMI Calculator (amortization schedule)
14. Savings Calculator
15. Tip Calculator
16. Unit Price Calculator (up to four items)
17. World Time

Settings, calculation History, Favorites, Help and Feedback are separate app surfaces.

## Currency reliability

- Refresh at converter initialization, hourly while visible, on eligible foreground resume, on network recovery, and manually. No per-second polling.
- Reference-rate sources do not guarantee live executable bank/card/remittance prices.
- Frankfurter v2 is the primary public global reference-rate API (no API key); Open ER-API and Fawaz Exchange API are public fallbacks. Fawaz jsDelivr and Cloudflare Pages are mirrors of one dataset, not independent sources.
- The app combines sources only when a selected currency is missing. Same-date observations from a different provider do not silently replace the provider already selected for that currency.
- Per-currency observation dates and provider provenance are cached and displayed for the selected pair. The pair date is the older of the two required observations; same-currency conversions do not claim an FX observation date.
- Open ER-API and Fawaz observations older than four calendar days are rejected; Frankfurter per-row observations use a ten-day ceiling. Older accepted cached observations are visibly marked as older in the converter.
- Currency selection now follows the supplied reference video: a curated 105-row list, alphabetically sorted by full display name, with 3-letter code, selected checkmark, search, and A–Z quick-jump rail. Provider-only currencies and accounting/metal/test codes do not silently add extra options. HRK is retained because it is visibly present in the reference. The list is a UI reference match, not a claim that every row is currently legal tender or supported by every rate provider.
- No private currency API, Cloudflare Worker, server-side currency proxy, provider credential, or paid API key is required. The currency converter calls public provider endpoints directly and retains its local last-known cache for offline use.
- Provider retries are bounded, jittered and delayed; foreground/network recovery is handled without bypassing an active retry timer.
- Currency results use ISO currency minor units and half-up decimal-string rounding for display only. Number grouping respects the app's comma, space, lakh or none setting; the unrounded result remains available when editing the converted amount.
- Open ER-API attribution is displayed when that source contributes to the selected pair.
- Last-known dated rates are usable offline; built-in estimates are separately labelled. Service Worker does not cache same-origin API responses.
- Currency swap keeps raw editable values synchronized. Charts and saved currency pairs are intentionally excluded.

## Settings, themes and History

12 settings groups cover Appearance; Theme & Colors; Calculator Settings; Decimal & Number Format; Navigation Language; Startup Preferences; Favorites Management; History Settings; Clipboard & Copy; Sound & Vibration; Privacy; and About & Support.

- Appearance Mode (Light/Dark/Follow System) is a visible control, separate from the 15-palette accent picker and accent-color selector.
- Font size, fullscreen and screen wake lock are included. Fullscreen/wake lock are session/device features and are not persisted as active browser permissions; unsupported/denied wake-lock requests revert the toggle.
- Language selection supports English, Hindi, Urdu, Spanish, French, German, Arabic and Chinese through the offline-first localization layer. The v1.94.0 localization rebuild contains 628 translation keys across seven translated languages, all 76 Unit Converter unit labels, and bundled CLDR currency names for 105 currencies in all eight locales. A 400-string static UI/accessibility inventory and dynamic-message regression tests are included. Native-speaker and physical Android/Acode review are still release gates; see `LOCALIZATION-AUDIT.md`.
- Settings restore is normalized and written back only after all preferences have loaded, avoiding early apply handlers overwriting settings that had not yet been restored.
- Help is a local guide dialog. Feedback opens a local form and only copies/shares when the user explicitly chooses; there is no automatic upload endpoint.
- History records standard calculator expressions/results (not tool-specific form values). It supports copy, reuse/edit, share, name/rename, protect/unprotect, delete unlocked entries and clear unlocked entries. Protected entries are retained; new protection/recording is blocked when all configured slots are protected.
- Clearing App Data & Cache removes local settings, history, saved inputs and browser caches after confirmation.

## Run and test

```sh
npm start
npm test
```

No currency API key or private backend configuration is required. The app uses the public Frankfurter, Open ER-API and Fawaz Exchange API endpoints. Provider availability and observation dates are validated at runtime.

## Verification boundary

Automated tests cover the currency engine, settings restore/persistence, history protections, navigation/action registry, representative tool formulas, loan schedule, unit/date/hex/world-time helpers, server routes, CSS structure and release assets. They do not prove live provider uptime, every possible currency pair, physical Android WebView behavior, signed APK installation, Play Store acceptance, legal clearance or zero defects. See `QA-REPORT.md` for exact results and outstanding manual checks.


## v88 currency refresh timestamps

The Currency Converter now shows two separate local-device timestamps beneath the rate status:

- **Last checked:** when the most recent completed refresh attempt finished, including failed attempts.
- **Rates last updated:** when the latest successful provider refresh completed. A failed attempt never overwrites this timestamp.

Both values are persisted in a dedicated local-storage metadata record, restored after app restart, validated against invalid/future timestamps, and migrated from the v87 cached-success timestamp when possible. Times use the device locale and timezone. This is the local refresh/check time, not the provider's exchange-rate observation date; the selected pair's observation date remains a separate concept.


## v89 currency observation freshness

- Currency refresh now queries all independent dated providers on each refresh instead of stopping as soon as the selected pair is present.
- Frankfurter v2 is evaluated first, followed by Open ER-API and Fawaz as independent public fallbacks. Per-currency observation dates still determine whether a newer fallback observation can be accepted.
- Per-currency merge keeps the newest validated provider observation date and rejects older observations, so a refresh on a new calendar day can adopt that day's data when a provider has published it.
- The app's local `Last checked` / `Rates last updated` timestamps remain separate from provider `rate date`. A daily provider cannot supply a new intraday market fixing merely because the app refreshed.


## v89 reference-matched currency picker

- Replaced the native Android currency dropdown with a full-screen, theme-aware picker matching the supplied screen recording.
- The 105 video-visible codes are presented in alphabetical order by currency name; each row shows the full name and ISO code, with a blue check on the selected row.
- Added live search by name or code and an A–Z jump rail.
- Selection updates the existing native select value and dispatches its normal change event, preserving rate refresh, display labels, conversion and swap logic.
- The curated list intentionally avoids appending provider-only, metal, fund, accounting and technical codes. A displayed option can still show an unavailable-rate state if the current provider does not publish that currency.


### Currency pair stability (v89.2)
The selected From/To ISO currency codes are saved independently of exchange-rate data. Rate refreshes update quotes only; they do not change currency identities or the user-selected pair. The pair is restored after app restart.


## v1.90.0-v90 release notes
- In-app header logo removed. Basic Calculator shows `SA Calculator`; every other screen shows its own translated title. App launcher/favicon icon retained.
- Added `SETTINGS-AUDIT.md` with all 12 settings groups, every visible control, persistence behaviour and platform limitations.
- Settings persistence, validation and reset behaviours retained; diagnostics remain disabled.


### Header naming behavior (v90.1)
The basic calculator header displays **SA Calculator**. Other screens display their own screen title (translated with the selected app language). The navigation drawer retains the SA Calculator brand. The header logo is removed; the PWA/launcher icon is retained.


## v91 whole-project audit and release corrections

- Re-ran the full automated suite from the supplied v90.1 archive. The original archive had two stale service-worker cache-name assertions; corrected the release-gate tests to match the actual cache version and added a regression check for feedback-report version metadata.
- Corrected the feedback/bug-report version from stale v87 text to the current release constant.
- Synchronized package, PWA manifest, HTML title, Settings version label, server User-Agent, and service-worker cache key to `1.91.0-v91` / `sa-calculator-v91-shell`.
- Updated release and audit documentation to reflect the accepted screen-specific header-title behavior.


## v92 unit-converter scientific display

- Unit Converter results now remain in grouped ordinary notation through 12 integer digits.
- When a result reaches 13 integer digits (the 1e12 boundary), it switches to scientific notation with up to 12 significant digits, e.g. `81,064,793,292,700,000` becomes `8.10647932927e+16`.
- Extremely small non-zero unit results also use scientific notation rather than rounding to a misleading zero.
- This is a display-only formatting change. Conversion factors, full calculation values, selected units, swap behavior, category lists, calculator keypad, and saved preferences are unchanged.
- Added focused regression tests for the 12-digit boundary, positive/negative large values, zero, very small values, invalid numeric values, and the Unit Converter output wiring.
- Release metadata and service-worker cache were advanced to `1.92.1-v92` / `sa-calculator-v92-1-92-1-glitch-fix-shell` to prevent stale UI code.


## v1.92.1-v92 video-glitch fixes

- Added a tiny synchronous theme bootstrap before the main stylesheet so the saved accent is applied on the first paint (prevents the visible teal/blue flash on Android).
- Moved transient toast notifications to the display area below the header so they no longer cover the bottom calculator keys.
- Added a five-second manual refresh tap guard to prevent duplicate currency refresh requests and repeated notifications. Automatic refresh remains silent.
- Bumped the service-worker cache key and precache list so installed Android/PWA copies receive the fix.


## v1.92.7-v92 release polish

- Added accessible live announcements for transient app status messages.
- Advanced the PWA shell cache namespace and synchronized current release metadata.
- Updated the file audit and release verification to describe the shipped public-provider architecture accurately.


## v1.92.7-v92 currency interaction update

- Swapping currencies now swaps both amounts and both currency codes, so the visible conversion is preserved in reverse.
- Both amount cards support keypad editing; changing either side recalculates the other side.
- Public provider values are reference rates and may differ from the final rates/fees charged by banks, cards, cash exchanges or remittance services.
- Converter keeps rate-source/freshness status and separate last-checked/last-successful-update timestamps visible and screen-reader announced.


## v1.92.7-v92 localization update

- Added the offline-first localization layer, eight-language selector integration, translated common Settings/navigation/tool phrases, accessible-label and placeholder translation, RTL document direction for Urdu/Arabic, locale-aware numeric glyphs and date formatting.
- Localization is phrase-catalogue based; unmatched text remains English. See `LOCALIZATION-AUDIT.md` before treating this as a fully translated release.
- At the localization-rebuild checkpoint the suite was 90/90; the current v1.94.0-v94 suite is 100/100 passing (see `RELEASE-VERIFICATION.md`).


## v1.94.0-v94 localization corrections

Input placeholders and accessibility attributes now pass through localization, dynamic text mutations no longer reuse stale original strings, and currency names/search ordering follow the selected locale where supported by the browser runtime. The merged catalogue has 628 keys, the static HTML inventory has 400 entries, all 76 unit labels are covered, and 105 currency names are bundled for each of the eight locales. Native-speaker and physical-device review remain outstanding.

## v1.94.0-v94 basic calculator and interaction polish

- Fixed malformed decimal token adjacency: inputs such as `1..2`, `1.2.3`, and `1e2.3` are rejected rather than silently evaluated as implicit multiplication.
- Completed the documented constant-adjacency behavior for `pi2`, `2pi2`, and `e2`; scientific notation such as `2e3` and `1e-7` remains intact.
- Corrected repeat-equals parsing so exponent signs in scientific notation are not mistaken for a binary subtraction/addition operation.
- Memory recall now clears stale result, repeat-operation and scientific-continuation state before replacing the current expression.
- Corrected the Strong vibration setting: the stored `heavy` value now maps to the intended 50 ms vibration (and old `strong` values remain compatible).
- Added focused regression coverage for arithmetic precedence, unary signs, grouping, contextual percentages, constants, implicit multiplication, scientific notation, degree/radian trigonometry, factorial/range errors, malformed numeric input, repeat-equals, memory/settings behavior, weighted GPA, loan grace periods, leap-day reminders and Kelvin absolute-zero boundaries.


## v1.94.0-v94 screen design polish
- Added a consolidated final visual layer for screen hierarchy, consistent cards/forms/results, touch target comfort, safe areas, compact screens, short-height devices and expanded tablet layouts.
- Added reduced-motion and forced-colors support and preserved LTR calculator math within RTL screens.
- See `SCREEN-DESIGN-AUDIT.md` for scope and remaining physical-device QA.

## v1.97.1-v97.1 server and accessibility hardening

- Hardened the optional Node static server against decoded NUL-byte paths so malformed requests return `400` instead of throwing during filesystem access.
- Corrected `HEAD` responses to return the matching content length without a response body, and made the server factory import-safe for repeatable automated tests.
- Added HTTP regression coverage for response security headers, HEAD behavior, encoded traversal, hidden files, unsupported methods and server survival after malformed paths.
- Fixed a dynamic option-picker accessibility edge case: when options are removed while the picker is open, the listbox now clears a stale `aria-activedescendant` before updating its active option.
- Automated suite: **108 passed, 0 failed** (see `RELEASE-VERIFICATION.md`). Physical Android/Acode and screen-reader testing remain separate manual gates.


## v1.97.1-v97.1 scientific result continuation fix

- Fixed a false `Error` preview after applying square root, cube root, trigonometric/logarithmic functions, factorial, percent, reciprocal or power actions. Successful scientific-key edits now use the shared parser's real preview rather than forcing an error state.
- Scientific functions tapped after `=` now operate on the committed answer, not the hidden previous expression.
- Scientific display tokens remain atomic and their full-precision underlying value is preserved when wrapped in a function (for example `√(8.337478 × 10¹⁷)`) or continued with an operator. Editing the visible token invalidates the exact-value mapping.
- Added regression coverage for scientific notation inside radicals, committed-result function expressions, continuation precision and finite-range overflow.
- Values outside JavaScript Number's finite range (for example `9^999` and `9^9999`) continue to be rejected as out of range rather than displaying a fabricated/incorrect result; arbitrary-precision arithmetic is not implemented in this release.

## v1.97.1-v97.1 live-preview Error row stability
- The live-preview error state now keeps the same row height/alignment as a normal preview instead of collapsing to a compact diagnostic row.
- Error text uses the exact font size measured by the live-preview fit routine, so the word `Error` matches the current preview text size at the active viewport.
- Error color remains distinct; layout and typography no longer switch to a smaller special-case scale.
- Regression suite: 118 passed, 0 failed, 0 skipped.


## v1.97.2-v97.2 — overflow-safe radical-of-power evaluation (2026-11-14)

A supplied Android screen recording showed `∛9^966` producing `Error` even though its final cube-root value (`9^322`) is within the finite IEEE-754 Number range. The parser previously evaluated `9^966` first, overflowed to Infinity, and rejected the expression before applying the cube root.

The leading radical parser now evaluates an unparenthesized power as `base^(exponent / degree)` for square/cube roots, preserving the finite-result case while continuing to reject genuinely out-of-range final results and invalid square-root domains. Regression coverage includes live preview, committed evaluation, negative cube-root sign, square-root domain rejection, and a still-overflowing cube-root case.

## v1.97.4-v97.4 — memory and parenthesized scientific-root integrity (2026-11-14)

- Added runtime regression coverage for MC/MR/MS/M+/M−, persistence, empty/corrupt storage, invalid inputs, and recall-state cleanup.
- Fixed parenthesized radical powers such as `∛(9^966)` and `√(9^324)` so a finite final root is evaluated without first overflowing the radicand.
- Added regression coverage for compact and parenthesized radical forms, overflow boundaries, and live preview.
- Bumped the app and service-worker cache version to prevent stale scripts from masking the fix.


## v1.97.5-v97.5 — exponent-marker semantics (2026-11-14)
- Changed `e` to exponent-entry marker only: bare `e` is an error, not Euler's constant.
- `e20` / `e+20` mean `1 × 10²⁰`; `e-20` means `1 × 10⁻²⁰`.
- Standard mantissa notation (`2e20`) remains supported and the formatted value is consistent before and after equals.


## v1.97.6-v97.6 — strict `e` marker and committed scientific display (2026-11-14)

- `e` is never Euler's constant in this calculator. A standalone `e`, `e^2`, or incomplete `2e` is invalid and must display `Error`.
- Exponent-only shorthand remains supported: `e2` = `1×10²`, `e20` = `1×10²⁰`, and `e-2` = `1×10⁻²`.
- The equals/committed-result path uses the same scientific-entry formatter as live preview, so `e20` remains `1×10²⁰` after equals rather than changing to an ordinary decimal or Euler value.
- Scientific notation is presentation-only; the raw numeric value remains the calculation source for subsequent operations.


## v1.97.9-v97.9 — scientific continuation preview consistency (2026-11-14)
- Fixed a recording-reproduced mismatch where a committed scientific result such as `1×10⁹` remained scientific in the expression row after an operator was pressed, but the secondary live-preview row reverted to locale-grouped decimal (`1,00,00,00,000`).
- `formatCalculatorExpressionResult()` now recognizes a scientific display token anywhere in the active expression and uses the shared scientific display formatter for the preview/result value.
- Exact numeric evaluation and `STATE.calcRawValue` / `STATE.calcScientificContinuation` remain authoritative; only presentation formatting is kept consistent.
- Added regression coverage for `1×10⁹×` → `1×10⁹`, `1×10⁹×2` → `2×10⁹`, and `1×10⁹+2` → `1.000000002×10⁹`.


## v1.98.2-v98.2 — e12 threshold and scientific memory recall (2026-11-14)
- Enforced the exact 12-digit ordinary / 13-digit scientific boundary for exponent-entry expressions: e11 displays 100000000000; e12 displays 1×10¹².
- Unified preview and equals formatting so scientific-entry syntax does not force scientific notation below the threshold.
- Memory Recall now restores scientific values using the same six-fractional-digit scientific display while retaining the exact stored numeric value for subsequent calculations.
- Added regression coverage for e11/e12, exponent-entry boundaries, and MS→MR scientific value round-tripping.
